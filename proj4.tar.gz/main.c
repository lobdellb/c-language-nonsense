/*  This file contains the main() function and some
other stuff for project 4, image minipulation.  */



#include <stdio.h>
#include "proj4.h"

int main()
{

Menu();



return 0;
}


