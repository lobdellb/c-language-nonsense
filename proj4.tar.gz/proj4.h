/*  This is the include file for project 4.  All function prototypes
and data type that have to be shared between files go in this header
file. */


#include <stdio.h>

#define INDEX(r,c,s) (s*r+c)

#define uchar unsigned char
#define uint unsigned int

struct Image
   {
   int Rows, Cols;
   int *Data;
   };


struct Mask
   {
   int Coef[3][3];
   };


/* These functions come from the file "menu.c" */
void Menu();

/* These functions come from the file "image.c" */
int SavePGM_Image(struct Image *Picture, FILE *File);
struct Image *LoadPGM_Image(FILE *File);
struct Image *New_Image(int Rows, int Cols);
void Delete_Image(struct Image *Pic);

