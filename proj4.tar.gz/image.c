/*  This file contains functions that handle this stuff:

These function are for "struct Image":

load image
save image
make new image
delete image


All these function deal with pointers to type "struct Image"
All handling of memory allocation should be done inside these
functions.
*/

#include <stdio.h>
#include "proj4.h"


/*  This function should load a pgm file image
int a "struct image".  It must allocate memory
for the image (*data) and for the "struct image".
If it is unable to load the image for one reason
or another, it should return the NULL pointer (0). */
struct Image *LoadPGM_Image(FILE *File)
{





}







/*  This function saves an image to a file.  It takes
a pointer to the "struct Image" that contains the picture
and writes it to the file pointed to by FILE *File. If anything
bad happens, return FALSE (0), otherwise return true. */
int SavePGM_Image(struct Image *Picture, FILE *File)
{




}



/*  This function creates a new image structure (struct Image).
It takes the size of the image to create, and it allocates memory
for the image structure, and it allocates memory for the image itself
(image.data).  You MUST use malloc.  If you just allocate memory
in this funciton by making an array, that memory will be erased
as soon as the function is finished.  This function returns a pointer
to the new image structure.  Also, this function should initialize
all data in the structure.  That means that each piece of data in the
"struct Image" should have a relevant value, and that also means that
every pixel in the image should be initialized to zero. */
struct Image *New_Image(int Rows, int Cols)
{





}


/*  This function should delete a "struct Image"  that means the
memory pointed to by image.data should be unallocated and the
memory pointed to by "struct Image *" should be unallocated.
All it takes is a pointer to a "struct Image" and it has no
return value. */ 
void Delete_Image(struct Image *Pic)
{





}

