/*  This file contains the code that operates the menu for
proj4 (image minipulation)  It includes these functions:

simple terminal menu
savefile function
loadfile function
help function

*/ 

#include <stdio.h>
#include "proj4.h"

#define NEWLINE ((int)'\n')
#define SPACE ((int)' ')
#define OPEN ((int)'O')
#define SAVE ((int)'S')
#define CLOSE ((int)'C')
#define HALFTONE ((int)'H')
#define EDGEDETECT ((int)'E')
#define HELP ((int)'?')
#define QUIT ((int)'Q')





/*  This function is called by the menu to load a file
from disk.  It must list available files, prompt the
user to enter a file.  Open the file and perform any
necessary error checking, and then call the LoadPGM_Image
function.  It doesn't take any arguments, and it returns
a pointer to the new image.  This function should only
be called by the "menu function".  If an error occures
this function should return 0 */ 
struct Image *Open_File()
{


}


/*  This function is called by the menu to load a file
from disk.  It must prompt the user for the filename.
It should perform any error checking, and if the file
name already exists, it should ask if the user wants
to overright the old file.  It should then call the
SavePGM_Image function.  This function takes a pointer
to a struct Image and should return zero if an error
occured */
int Save_File(struct Image *Pic)
{

} 




void Help()
{

printf(
"Image Minipulation Program (Project 4)\n\n"
"Commands:\n"
"O - Open File\n"
"S - Save File\n"
"C - Close File (No Save)\n"
"H - Halftone Image\n"
"E - Edge Detection\n"
"Q - Exit Program\n"
"? - Display This Menu Again\n"
);


}















/*  This function makes a character upper case. */
char Charupr(int C)
{

if ((C >= 97) && (C <= 122))
  C -= 32;

return C;
}



/*  This function implements a simple menu */
void Menu(void)
{
char Command;
int Quit = 1;

Help();

do {
   scanf("%c",&Command);
      Command = Charupr(Command);

   switch((int)(Command))
      {
      case (SAVE):
         {

         break;
         }

      case (OPEN):
         {

         break;
         }

      case (CLOSE):
         {

         break;
         }

      case (HALFTONE):
         {

         break;
         }

      case (EDGEDETECT):
         {

         break;
         }

      case (HELP):
         {
         Help();
         break;

         }
      
      case (QUIT):
         {
         Quit = 0;
         break;
         }
     
      case (NEWLINE):
         break;

      case (SPACE):
         break;

      default:
         printf("Invalid Command\n");
      }

   } while (Quit);

}
