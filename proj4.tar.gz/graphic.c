/*  This file contains functions that minipulate the image stored in
a "struct Image".  These functions currently include:

pass a 3x3 matrix (mask) over an image
make a histogram of an image and store it in an array


*/


#include "proj4.h"


/*  This function applies the mask contained in "Filter" to the
image contained in "Pic".  This is meant to be a general function.
A variety of masks can be used to do a variety of special effects. */
struct Image *Apply_Mask(struct Mask *Filter, struct Image *Pic)
{





}
